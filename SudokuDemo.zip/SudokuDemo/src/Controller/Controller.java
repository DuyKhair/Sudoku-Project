package Controller;

public interface Controller {

	public void makeNewGame();

}
